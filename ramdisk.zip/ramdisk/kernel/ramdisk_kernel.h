#include <linux/module.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <asm/uaccess.h>
#include <linux/vmalloc.h>
#include <linux/string.h>
#include <linux/ioctl.h>

#define BLOCK_SIZE              256     
#define INODE_SIZE              64      
#define INODE_ARRAY_SIZE        256     
#define BITMAP_SIZE             4       
#define MAX_NUM_FILE            1024  
#define MAX_FILE_SIZE           1067008  
#define INODE_NUM_DIRECT_PTR    8

#define RD_INIT    _IOW(0, 0, ioctl_params_t*)
#define RD_CREATE  _IOW(0, 1, ioctl_params_t*)
#define RD_MKDIR   _IOW(0, 2, ioctl_params_t*)
#define RD_OPEN    _IOW(0, 3, ioctl_params_t*)
#define RD_CLOSE   _IOW(0, 4, ioctl_params_t*)
#define RD_READ    _IOW(0, 5, ioctl_params_t*)
#define RD_WRITE   _IOW(0, 6, ioctl_params_t*)
#define RD_LSEEK   _IOW(0, 7, ioctl_params_t*)
#define RD_UNLINK  _IOW(0, 8, ioctl_params_t*)
#define RD_READDIR _IOW(0, 9, ioctl_params_t*)

typedef struct ioctl_params {
	int size;  
	int pid;
	int fd;
	char* pathname;
    char* data;
} ioctl_params_t;


typedef struct SUPERBLOCK {
    unsigned int free_blocks; 
    unsigned int free_inodes; 
    char padding[248];        
} superblock_struct;;

typedef struct DIR_ENTRY {
	char name[14];             
	unsigned short inode_num;  
} dir_entry_struct;

typedef union DATA_BLOCK data_block_struct;
union DATA_BLOCK {
    char data[BLOCK_SIZE];
    dir_entry_struct entries[BLOCK_SIZE/sizeof(dir_entry_struct)];
    data_block_struct* index_block[BLOCK_SIZE/4];   
};

typedef struct I_NODE {
    char type[4];     
    int size;      
    data_block_struct *locations[10]      
    char padding[14];
} inode_struct;

typedef struct ramdisk {
    superblock_struct superblock;
    inode_struct inodes[INODE_ARRAY_SIZE*BLOCK_SIZE/INODE_SIZE];
    unsigned char bitmap[BITMAP_SIZE*BLOCK_SIZE]; 
    data_block_struct data_blocks[7931];
} ramdisk_struct;

typedef struct file_boject{
    inode_struct* inode_ptr;
    unsigned int status;
    unsigned int cursor;
    unsigned int pos;
    unsigned int status;
} file_object_struct;

typedef struct file_descriptor_table {
    file_object file_objects[1024];
} file_descriptor_table_struct;

typedef struct fdt_process {
    unsigned int pid;
    file_descriptor_table fd_table;
} fdt_process_struct;

int rd_create(char *pathname, char* type, int mode);
int rd_mkdir(char* pathname);
int rd_open(char *_pathname, int pid);
int rd_close(int _fd, int pid);
int rd_read(int _fd, char *_addr, int num_bytes, int pid);
int rd_write(int fd, int pid, char *data, int num_bytes);
int rd_lseek(int _fd, int offset, int pid);
int rd_unlink(char *pathname);
int rd_readdir(int _fd, char *address, int pid);