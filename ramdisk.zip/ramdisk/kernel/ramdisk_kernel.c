#include "ramdisk_kernel.h"


/* global variables */
filesys_struct* ramdisk;
fdt_process_struct* p_fd_table;
char copy_buffer_to_user[64*64*256];

// find a free block from bitmap
int find_free_block_bitmap() {
    int total_bytes = 1024; 
    int max_blocks = total_bytes * 8; 

    for (int i = 0; i < total_bytes; i++) {
        if (ramdisk->bitmap[i] != 255) {
            for (int j = 0; j < 8; j++) {
                if ((ramdisk->bitmap[i] & (1 << j)) == 0) {
                    int free_block = i * 8 + j;
                    if (free_block < max_blocks) {
                        return free_block;
                    }
                }
            }
        }
    }
    return -1; 
}

// given pathname find the inode number
int find_parent_directory_inode(char* pathname){
    char *curr_path = (char *)vmalloc(strlen(pathname));
    int curr_node = 0;
    int found_directory = 0;
    strcpy(curr_path, pathname);
    // parent directory is root
    if (strcmp(curr_path, "/") == 0){
        return 0;
    }

    char *searching_path = strsep(&curr_path, "/");

    data_block_struct *curr_block = NULL;
    // loop from root to parent directory to find parent inode
    while(searching_path != NULL){
        int i;
        // search 8 direct pointers first
        for (i = 0; i < 8; i++){
            curr_block = ramdisk->index_node_data[curr_node].location[i];
            // nothing inside datablock
            if (curr_block != NULL){
                int j;
                // 16 entries in a block
                for (j = 0; j < 16; j++){
                    dir_entry_struct *curr_entry = curr_block->dir_entries[j];
                    if (strcmp(curr_entry->name, searching_path) == 0){
                        curr_node = curr_entry->inode_index;
                        found_directory = 1;
                        break;
                    }
                }
            }
            if (found_directory == 1){
                break;
            }
        }
        // go to next iteration of path or parent directory i node found
        if (found_directory == 1){
            searching_path = strsep(&curr_path, "/");
            found_directory = 0;
            continue;
        }

        // search single indirect pointer
        data_block_struct *single_indirect_block = ramdisk->index_node_data[curr_node].location[8];
        if (single_indirect_block != NULL){
            int k;
            // 256 bytes / 4 bytes for a pointer, 64 pointers in a block
            for (k = 0; k < 64; k++){
                curr_block = single_indirect_block->index_block[k];
                if (curr_block != NULL){
                    int l;
                    for (l = 0; l < 16; l++){
                        dir_entry_struct *curr_entry = curr_block->dir_entries[l];
                        if (strcmp(curr_entry->name, searching_path) == 0){
                            curr_node = curr_entry->inode_index;
                            found_directory = 1;
                            break;
                        }
                    }
                }
                if (found_directory == 1){
                    break;
                }
            }
        }
        if (found_directory == 1){
            searching_path = strsep(&curr_path, "/");
            found_directory = 0;
            continue;
        }

        // search double indirect pointer
        data_block_struct *double_indirect_block = ramdisk->index_node_data[curr_node].location[9];
        if (double_indirect_block != NULL){
            int m;
            for (m = 0; m < 64; m++){
                data_block_struct *single_indirect_block = double_indirect_block->index_block[m];
                if (single_indirect_block != NULL){
                    int n;
                    for (n = 0; n < 64; n++){
                        curr_block = single_indirect_block->index_block[n];
                        if (curr_block != NULL){
                            int o;
                            for (o = 0; o < 16; o++){
                                dir_entry_struct *curr_entry = curr_block->dir_entries[o];
                                if (strcmp(curr_entry->name, searching_path) == 0){
                                    curr_node = curr_entry->inode_index;
                                    found_directory = 1;
                                    break;
                                }
                            }
                        }
                        if (found_directory == 1){
                            break;
                        }
                    }
                }
                if (found_directory == 1){
                    break;
                }
            }
        }
        if (found_directory == 1){
            searching_path = strsep(&curr_path, "/");
            found_directory = 0;
            continue;
        }
        // directory not found in any of the blocks 
        return -1;
    }
    // escapes when it parses through the full parent directory path (from root -> parent directory)
    return curr_node;

}

// function to separate parent and child
void separate_child_parentpath(char* path, char* child_dir, char* filename) {
    int i;
    int len = strlen(path);

    // find the last occurrence of '/'
    for (i = len - 1; i >= 0; i--) {
        if (path[i] == '/') {
            // separate child directory path
            if (i != 0) {
                strncpy(child_dir, path, i);
                child_dir[i] = '\0';
            } else {
                strcpy(child_dir, "/"); 
            }
            break;
        }
    }

    // copy the filename part
    strcpy(filename, &path[i + 1]);
}


int reset_bitmap(int index) {
    int byte_index = index / 8;
    int bit_offset = index % 8;

     if (index < 0){
        return -1;
    }
    if (index > 1024*8){
        return -1;
    }

    unsigned char mask = ~(1 << bit_offset); // create a mask to clear the bit

    ramdisk->bitmap[byte_index] &= mask; // clear the bit by ANDing with the mask

    return 0;
}

int set_bitmap(int index) {
    int byteIndex = index / 8; 
    int bitOffset = index % 8;
    if (index < 0){
        return -1;
    }
    if (index > 1024*8){
        return -1;
    }

    unsigned char mask = (1 << bitOffset); // create a mask to set the bit
    ramdisk->bitmap[byteIndex] |= mask; // set the bit by ORing with the mask

    return 0; 
}

// get free inode
int get_free_inode_num() {
    int i;
    if ( ramdisk->superblock.free_inodes <= 0 ) {
        return -1;
    }
    for(i = 1; i < MAX_NUM_FILE; i++) {
        inode_struct inode = ramdisk->inodes[i];
        if(strcmp(inode.type, "") == 0) {
            return i;
        }
    }
    return -1;
}


data_block_struct* allocate_data_block(int free_block_number) {
    set_bitmap(ramdisk->bitmap, free_block_number);
    ramdisk->superblock.free_blocks--;
    memset(&ramdisk->data_blocks[free_block_number], 0, BLOCK_SIZE);     
    return &ramdisk->data_blocks[free_block_number];
}

// find the next directory entry for a block
dir_entry_struct* get_next_dir_entry(data_block_struct* block) {
    int j;
    for ( j = 0; j < BLOCK_SIZE/16; j++ ) {
        if ( block->entries[j].inode_num == 0 ) {
            return &block->entries[j];
        }
    }
    return NULL;
}

// get the next directory entry from a single indirect block - helper for get_next_entry
dir_entry_struct* get_next_dir_entry_single(data_block_struct* single_indirect, int segment) {
    int seg = segment;
    data_block_struct* block = single_indirect->index_block[seg];

    // If block is empty, allocate a new one and return the first entry
    if (block == NULL) {
        int free_block_num = find_free_block_bitmap();
        if (free_block_num == -1) {
            return NULL; // no free block available
        }

        data_block_struct* new_data_block = allocate_data_block(free_block_num);

        single_indirect->index_block[seg] = new_data_block;

        return &single_indirect->index_block[seg]->entries[0];
    }

    return get_next_dir_entry(single_indirect->index_block[seg]);
}

// get the next entry from the current inode
dir_entry_struct* get_next_entry(inode_struct* node) {
    int seg = node->size / BLOCK_SIZE;

    // check direct pointers for available space
    for (int i = seg; i < INODE_NUM_DIRECT_PTR; i++) {
        data_block_struct* dir_ptr = node->pointers[i];
        if (dir_ptr == NULL) {
            int free_block_num = find_free_block_bitmap();
            if (free_block_num == -1) {
                return NULL; // no free block available
            }

            data_block_struct* new_data_block = allocate_data_block(free_block_num);
            node->pointers[i] = new_data_block;
            return &node->pointers[i]->entries[0];
        }

        dir_entry_struct* free_dir_entry = get_next_dir_entry(dir_ptr);
        if (free_dir_entry != NULL) {
            return free_dir_entry; // return the next entry if found
        }
    }

    // Check single indirect pointers for available space
    if (seg >= 8 && seg < (8 + 64)) {
        if (node->single_indirect_ptrs == NULL) {
            int free_block_num = find_free_block_bitmap();
            if (free_block_num == -1) {
                printk("cannot find free blocks.\n");
                return NULL;
            }
            data_block_struct* new_index_block = allocate_data_block(free_block_num);
            node->single_indirect_ptrs = new_index_block;
        }

        dir_entry_struct* free_dir_entry = get_next_dir_entry_single(node->single_indirect_ptrs, seg - 8);
        if (free_dir_entry != NULL) {
            return free_dir_entry; // return the next entry if found
        }
        seg = 72;
    }
    // check double indirect pointers for available space
    if (seg >= (8 + 64) && seg < (8 + 64 + 64 * 64)) {
        if (node->double_indirect_ptrs == NULL) {
            int free_block_num = find_free_block_bitmap();
            if (free_block_num == -1) {
                return NULL; // no free block available
            }

            data_block_struct* new_index_block = allocate_data_block(free_block_num);
            node->double_indirect_ptrs = new_index_block;
        }
        seg = seg - 72;
        seg = seg / 64;
        data_block_struct* block = double_indirect->index_block[seg];
        if (block == NULL) {
            int free_block_num = find_free_block_bitmap();
            if (free_block_num == -1) {
                return NULL; // no free block available
            }
            data_block_struct* new_index_block = allocate_data_block(free_block_num);
            block = new_index_block;

            return get_next_dir_entry_single(block, segment % 64);
        }
    }
    return NULL; 
}


// set inode to to empty
void reset_inode(inode_struct* inode) {

	data_block_struct* temp_block_ptr;
	int i;
	for ( i = 0; i < INODE_NUM_DIRECT_PTR; i++ ) {
		temp_block_ptr = inode->pointers[i];
		if ( temp_block_ptr != NULL ) {
			// use pointer substraction to get the number of the target block
			reset_bitmap(ramdisk->bitmap, temp_block_ptr - &ramdisk->data_blocks[0]);
			memset(inode->pointers[i], 0, BLOCK_SIZE);
			ramdisk->superblock.free_blocks++;
		}
	}
	if ( inode->single_indirect_ptrs != NULL ) {
		remove_single_indirect(inode->single_indirect_ptrs);
	}

	if ( inode->double_indirect_ptrs != NULL ) {
		int i;
        for ( i = 0; i < 64; i++ ) {
            data_block_struct* single_indirect = double_indirect->index_block[i];
            if ( single_indirect != NULL ) {
                remove_single_indirect(single_indirect);
            }
        }
        reset_bitmap(ramdisk->bitmap, double_indirect - &ramdisk->data_blocks[0]);
        memset(double_indirect, 0, BLOCK_SIZE);
        ramdisk->superblock.free_blocks++;
	}

}

void remove_single_indirect(data_block_struct* single_indirect) {
	int i;
	for ( i = 0; i < 64; i++ ) {
		data_block_struct* block = single_indirect->index_block[i];
		if (  block != NULL ) {	
			reset_bitmap(ramdisk->bitmap, block - &ramdisk->data_blocks[0]);
			memset(single_indirect->index_block[i], 0, BLOCK_SIZE);
			ramdisk->superblock.free_blocks++;
		}
	}
	reset_bitmap(ramdisk->bitmap, single_indirect - &ramdisk->data_blocks[0]);
	memset(single_indirect, 0, BLOCK_SIZE);
	ramdisk->superblock.free_blocks++;
}

file_object* create_file_object(int pid) {
    int i;
    file_descriptor_table* file_objects = get_fd_table(pid);

    if ( file_objects == NULL ) {
        return NULL;
    }

    for ( i = 0; i < FD_TABLE_SIZE; i++ ) {
        if ( file_objects->file_objects[i].status == 0 ) {
            file_objects->file_objects[i].pos = i;
            file_objects->file_objects[i].status = 1;
            return &file_objects->file_objects[i];
        }
    }
    return NULL;
}


file_descriptor_table* get_fd_table(int pid) {
    int i;

    // find the file object
    for ( i = 0; i < THERAD_POOL_SIZE; i++ ) {
        if ( p_fd_table[i].pid == pid ) {
            return &p_fd_table[i].fd_table;
        }
    }
    return NULL;
}

int clear_entry_in_child_dir(inode_struct* child_inode, char* filename) {
	dir_entry_struct* entry;  
    int findEntry = 0; 
	int i;
	for ( i = 0; i < INODE_NUM_DIRECT_PTR; i++ ) {
		data_block_struct* block = child_inode->pointers[i];
        int nonEmptyEntries = 0;
		if ( block != NULL ) {
			int j;
			for ( j = 0; j < BLOCK_SIZE/16; j++ ) {
				entry = &block->entries[j];
                if ( entry->inode_num != 0 ) {
                    // printf("  entry->inode_num %d\n", entry->inode_num);
                    nonEmptyEntries += 1;
                }
                if ( entry != NULL && strcmp(entry->name, filename) == 0 ) {
                    
                    memset(entry, 0, sizeof(dir_entry_struct));
                    entry = NULL;
                    findEntry = 1;
                }
			}
		}
        if ( findEntry == 1 && nonEmptyEntries == 1 ) {
            reset_bitmap(ramdisk->bitmap, child_inode->pointers[i] - &ramdisk->data_blocks[0]);
            child_inode->pointers[i] = NULL;
            print_bitmap(ramdisk->bitmap);
            
        }
	}
	return 0;
}

int init_ramdisk() {
	int retval;
	ramdisk = (filesys_struct*)vmalloc(sizeof(filesys_struct));
    memset(ramdisk, 0, RAMDISK_SIZE);
    p_fd_table = (fdt_process_struct*)vmalloc(sizeof(fdt_process_struct)*THERAD_POOL_SIZE);
    memset(p_fd_table, 0, sizeof(fdt_process_struct)*THERAD_POOL_SIZE);
	if ( !ramdisk ) {
		printk("ramdisk malloc fail.\n");
		return -1;
	}
	ramdisk->superblock.free_blocks = DATA_BLOCKS_NUM;
	ramdisk->superblock.free_inodes = MAX_NUM_FILE;
	retval = rd_mkdir("/");
	return retval;
}

// create a regular file with absolute pathname from the root of the directory tree, where each directory filename is delimited by a "/" character.  
// On success, you should return 0, else if the file corresponding to pathname already exists you should return -1, indicating an error. 
// Note that you need to update the parent directory file, to include the new entry. 
int rd_create(char *pathname, char* type, int mode) {
    char *parent_path = vmalloc(strlen(pathname));
    char *entry_name = vmalloc(strlen(pathname));
    memset(current_path, 0, strlen(current_path));
    memset(entry_name, 0, strlen(entry_name));
    separate_child_parent_path(pathname, parent_path, entry_name);
    // make sure there are free inodes and blocks
    if (ramdisk->superblock.free_inodes <= 0) {
        return -1;
    }

    if (ramdisk->superblock.free_blocks <= 0) {
        return -1;
    }

    // find the inode of the current directory
    int cur_inode_num = find_parent_directory_inode(parent_path);
    if ( cur_inode_num == -1 ) {
        return -1;
    }
    inode_struct* parent_path_inode = &ramdisk->inodes[cur_inode_num];

    // find the next free entry in current directory
    dir_entry_struct* free_dir_entry = get_next_entry(parent_path_inode);
    if ( free_dir_entry == NULL ) {
        printk("No free entry!\n");
        return -1;
    }

    // find the next free inode
    int free_inode_num = get_free_inode_num();
    if ( free_inode_num == -1 ) {
        return -1;
    }

    // allocate child in new inode and update global structs
    ramdisk->superblock.free_inodes--;
    memset(&ramdisk->inodes[free_inode_num], 0, INODE_SIZE);
    inode_struct* free_inode = &ramdisk->inodes[free_inode_num];
    strcpy(free_dir_entry->name, entry_name);
    free_dir_entry->inode_num = free_inode_num;
    strcpy(free_inode->type, type);
    parent_path_inode->size += 16;
    vfree(parent_path);
    vfree(entry_name);
    
    return 0;
}

// this behaves like rd_creat() but pathname refers to a directory file. If the file already exists, return -1 else return 0. Note that you need to update the parent directory file, to include the new entry.
int rd_mkdir(char* pathname) {
    int ret = rd_create(pathname, "dir", 1);
	vfree(pwd);
	vfree(filename);
	return 0;
}

// open an existing file corresponding to pathname (which can be a regular or directory file) or report an error if file does not exist. 
// When opening a file, you should return a file descriptor value that will index into the process'  ramdisk file descriptor table. As stated earlier, this table entry will contain a pointer to a file object. 
// You can assume the file object has the file position set to 0. Return a value of -1 to indicate an error, if the file does not exist.
int rd_open(char *_pathname, int pid) {
    memset(pathname, 0, strlen(pathname));
    strcpy(pathname, _pathname);
	
    // can not open root
	if ( strcmp(pathname, "/") == 0 ) {
		return -1;
	}

    // find inode of file
	int file_inode_num = find_parent_directory_inode(pathname);
	if ( file_inode_num == -1 ) {
		return -1;
	}
    
    // declare new file object and add to the running process
    inode_struct* file_inode = &ramdisk->inodes[file_inode_num];
    file_object* file_object = create_file_object(pid);
    file_object->cursor = 0;
    file_object->inode_ptr = file_inode;
    vfree(pathname);
    return file_object->pos;
}


// close the corresponding file descriptor and release the file object matching the value returned from a previous rd_open(). Return 0 on success and -1 on error. An error occurs if fd refers to a non-existent file.
int rd_close(int _fd, int pid) {
    int i;
    file_object* file_object = NULL;
    
    file_descriptor_table* file_objects = get_fd_table(pid);
    if ( file_objects == NULL ) {
        return -1;  
    }
    
    for ( i = 0; i < FD_TABLE_SIZE; i++ ) {
        if ( file_objects->file_objects[i].pos == _fd ) {
            file_object = &file_objects->file_objects[i];
            break;
        }
    }
    
    if ( file_object == NULL ) {
        return -1;
    }
    
    inode_struct* inode = file_object->inode_ptr;
    if ( inode == NULL ) {
        return -1;
    }

    if ( file_object->status != 1 ) {
        return -1;
    }

    if ( strcmp(inode->type, "dir\0") == 0 ) {
        return -1;
    }

    //remove file object
    if ( file_object->status == 1 ) {
        file_object->inode_ptr = NULL;
        file_object->status = 0;
        file_object->cursor = 0;
        file_object->pos = 0;
        return 0;
    }

    return -1;
}

// read up to num_bytes from a regular file identified by file descriptor, fd, into a process' location at address. You should return the number of bytes actually read, else -1 if there is an error. 
// An error occurs if the value of fd refers either to a non-existent file or a directory file. 
int rd_read(int _fd, char *_addr, int num_bytes, int pid) {
    int i;

    // find the fd_table
    file_object* file_object = NULL;
    
    file_descriptor_table* file_objects = get_fd_table(pid);
    
    int i;
    for ( i = 0; i < FD_TABLE_SIZE; i++ ) {
        if ( file_objects->file_objects[i].pos == _fd ) {
            file_object = &file_objects->file_objects[i];
            break;
        }
    }
    
    if ( file_object == NULL ) {
        return -1;
    }
    
    inode_struct* inode = file_object->inode_ptr;
    if ( inode == NULL ) {
        return -1;
    }

    if ( file_object->status != 1 ) {
        return -1;
    }

    if ( strcmp(inode->type, "dir\0") == 0 ) {
        return -1;
    }


    /* preprocess finish */
    int bytes_read = 0;
    int bytes_to_read = num_bytes;
    if ( num_bytes > inode->size - file_object->cursor ) {
        bytes_to_read = inode->size;
        return -1;
    }

    memset(copy_buffer_to_user, 0, sizeof(bytes_to_read));

    int seg = file_object->cursor / BLOCK_SIZE;
    int offset = file_object->cursor % BLOCK_SIZE;

    /* read in the direct blocks */
    for ( i = seg; i < INODE_NUM_DIRECT_PTR; i++ ) {
        data_block_struct* direct_block = inode->pointers[i];
        if ( direct_block != NULL ) {
            int j;
            for ( j = offset; j < BLOCK_SIZE; j++ ) {
                if ( direct_block->data[j] != '\0' ) {
                    copy_buffer_to_user[bytes_read] = direct_block->data[j];
                    bytes_read += 1;
                    file_object->cursor += 1;
                    if ( bytes_read == bytes_to_read ) {
                        break;
                    }
                }
            }
        }
        if ( bytes_read == bytes_to_read ) {
            break;
        }
    }

    // read single indirect
    
    seg = file_object->cursor / BLOCK_SIZE;
    offset = file_object->cursor % BLOCK_SIZE;
    if ( bytes_read < bytes_to_read && seg >= 8 && seg < (8+64) ) {
        data_block_struct* single_indirect = inode->single_indirect_ptrs;       
        seg = seg - 8;
        if ( single_indirect != NULL ) {
            // iterate single indirect index
            for ( i = seg; i < BLOCK_SIZE/4; i++ ) {
                data_block_struct* block = single_indirect->index_block[i];
                if ( block != NULL ) {
                    // iterate the data block
                    int j;
                    for ( j = offset; j < BLOCK_SIZE; j++ ) {
                        if ( block->data[j] != '\0' ) {
                            copy_buffer_to_user[bytes_read] = block->data[j];
                            bytes_read += 1;
                            file_object->cursor += 1;
                            if ( bytes_read == bytes_to_read ) {
                                break;
                            }
                        }
                    }
                }
                if ( bytes_read == bytes_to_read ) {
                    break;
                }
            }
            
        }
    }
    
    /* read in double indirect */
    seg = file_object->cursor / BLOCK_SIZE;
    offset = file_object->cursor % BLOCK_SIZE;
    if ( bytes_read < bytes_to_read && seg >= (8 + 64) && seg < (8 + 64 + 64*64) ) {
        data_block_struct* double_indirect = inode->double_indirect_ptrs;
        if ( double_indirect != NULL ) {
            seg = seg - 8 - 64;
            // iterate the single indirect index blocks
            for ( i = 0; i < BLOCK_SIZE/4; i++ ) {
                data_block_struct* single_indirect = double_indirect->index_block[i];
                if ( single_indirect != NULL ) {
                    seg = seg/64;
                    int j;
                    for ( j = seg; j < BLOCK_SIZE/4; j++ ) {
                        data_block_struct* block = single_indirect->index_block[j];
                        if ( block != NULL ) {
                            // begin to read
                            int k;
                            for ( k = offset; k < BLOCK_SIZE; k++ ) {
                                if ( block->data[k] != '\0' ) {
                                    copy_buffer_to_user[bytes_read] = block->data[k];
                                    bytes_read += 1;
                                    file_object->cursor += 1;
                                    if ( bytes_read == bytes_to_read ) {
                                        break;
                                    }
                                }
                            }
                        }
                        if ( bytes_read == bytes_to_read ) {
                            break;
                        }
                    }

                }
                if ( bytes_read == bytes_to_read ) {
                    break;
                }
            }
        }

    }
    char* src = copy_buffer_to_user;
    char* dst = _addr;
    int left = bytes_to_read;
    while(1) {
        if(left > 4096) {
            copy_to_user(dst, src, 4096);
            left -= 4096;
            src += 4096;
            dst += 4096;
        }
        else {
            copy_to_user(dst, src, left);
            flag = 1;
        }
    }
    return bytes_read;  

}

//write up to num_bytes from the specified address in the calling process to a regular file identified by file descriptor, fd. You should return the actual number of bytes written, or -1 if there is an error. 
//An error occurs if the value of fd refers either to a non-existent file or a directory file. 
int rd_write(int fd, int pid, char *data, int num_bytes) {
    // needs to be open, having file object in FDT
    file_object* file_object = NULL;
    file_descriptor_table* file_objects = get_fd_table(pid);
    int i;
    int written_bytes = 0;
    unsigned int cursor = file_object->cursor;
    int seg = 0;
    int offset = 0;

    // find file object from the table
    for (i = 0; i < 1024; i++) {
        if (file_objects->file_objects[i].pos == fd) {
            file_object = &file_objects->file_objects[i];
            break;
        }
    }
    
    inode_struct* inode = file_object->inode_ptr;
    if (inode == NULL) {
        return -1;
    }
    if (strcmp(inode->type, "dir") == 0) {
        return -1;
    }
    // find the segment of data and the offset in that block
    seg = cursor / BLOCK_SIZE;
    offset = cursor % BLOCK_SIZE;

    // check if seg is less than number of direct blocks
    for ( i = seg; i < 8; i++ ) {
        if ( inode->pointers[i] == NULL ) {
            // get a new block if this direct block is empty
            int free_block_num = find_free_block_bitmap();
            if ( free_block_num == -1 ) {
                return -1;
            }
            inode->pointers[i] = allocate_data_block(free_block_num);
        }
        data_block_struct* direct_block = inode->pointers[i];
        int j;
        for ( j = offset; j < BLOCK_SIZE; j++ ) {
            if (data[written_bytes] != '\0') {
                direct_block->data[j] = data[written_bytes];
                written_bytes += 1;
                file_object->cursor += 1;
                inode->size += 1;
                if ( written_bytes == num_bytes ) {
                    return written_bytes;
                }
            }
        }
    }

    seg = inode->size / BLOCK_SIZE;
    offset = inode->size % BLOCK_SIZE;
    if ( seg >= 8 && seg < (8+64) ) {
        data_block_struct* single_indirect = inode->single_indirect_ptrs;
        if ( single_indirect == NULL ) {
            int free_block_num = find_free_block_bitmap();
            if ( free_block_num == -1 ) {
                return -1;
            }
            inode->single_indirect_ptrs = allocate_data_block(free_block_num); 
            single_indirect = inode->single_indirect_ptrs;
        }
        
        // iterate the 64 index block
        seg = seg - 8;     
        for ( i = seg; i < BLOCK_SIZE/4; i++ ) {
            data_block_struct* block = single_indirect->index_block[i];
            if ( block == NULL ) {
                int free_block_num = find_free_block_bitmap();
                if ( free_block_num == -1 ) {
                    return -1;
                }
                single_indirect->index_block[i] = allocate_data_block(free_block_num);
                block = single_indirect->index_block[i];
            }

            // begin to write
            int j;
            for ( j = offset; j < BLOCK_SIZE; j++ ) {
                if ( data[written_bytes] != '\0' ) {
                    block->data[j] = data[written_bytes];
                    written_bytes += 1;
                    file_object->cursor += 1;
                    inode->size += 1;   
                    if ( written_bytes == num_bytes ) {
                        printk("rd_write: written_byte=%d\n", written_bytes);
                        return written_bytes;
                    }
                }
            }
        }
    }

    seg = inode->size / BLOCK_SIZE;
    offset = inode->size % BLOCK_SIZE;
    // write in double indirect block
    if ( seg >= (8 + 64) && seg < (8 + 64 + 64*64) ) {

        data_block_struct* double_indirect = inode->double_indirect_ptrs;
        if ( double_indirect == NULL ) {
            int free_block_num = find_free_block_bitmap();
            if ( free_block_num == -1 ) {
                return -1;
            }
            inode->double_indirect_ptrs = allocate_data_block(free_block_num);
            double_indirect = inode->double_indirect_ptrs;
        }

        seg = seg - 8 - 64;

        for ( i = 0; i < BLOCK_SIZE/4; i++ ) {
            data_block_struct* single_indirect = double_indirect->index_block[i];
            if ( single_indirect == NULL ) {
                int free_block_num = find_free_block_bitmap();
                if ( free_block_num == -1 ) {
                    return -1;
                }
                inode->double_indirect_ptrs->index_block[i] = allocate_data_block(free_block_num);
                single_indirect = inode->double_indirect_ptrs->index_block[i];
            }
            
            seg = seg/64;
            int j;
            for ( j = seg; j < BLOCK_SIZE/4; j++ ) {
                data_block_struct* block = single_indirect->index_block[j];
                if ( block == NULL ) {
                    int free_block_num = find_free_block_bitmap();
                    if ( free_block_num == -1 ) {
                        printk("<1> rd_write: no free block found!\n");
                        return -1;
                    }
                    single_indirect->index_block[j] = allocate_data_block(free_block_num);
                    block = single_indirect->index_block[j];
                }

                // begin to write
                int k;
                for ( k = offset; k < BLOCK_SIZE; k++ ) {
                    if ( data[written_bytes] != '\0' ) {
                        block->data[k] = data[written_bytes];
                        written_bytes += 1;
                        file_object->cursor += 1;
                        inode->size += 1;
                        if ( written_bytes == num_bytes ) {
                            printk("rd_write: written_byte=%d\n", written_bytes);
                            return written_bytes;
                        }
                    }
                }

            }

        }

    }
    if ( seg >= (8 + 64 + 64*64) ) {
        return written_bytes;
    }
    return 0;  

}

//remove the filename with absolute pathname from the filesystem, freeing its memory in the ramdisk. 
//This function returns 0 if successful or -1 if there is an error. 
//An error can occur if: (1) the pathname does not exist, (2) you attempt to unlink a non-empty directory file, (3) you attempt to unlink an open file, or (4) you attempt to unlink the root directory file.
int rd_unlink(char* _pathname) {
	char* pathname = vmalloc(strlen(_pathname));
    char*child_pathname = vmalloc(strlen(pathname));
	char* filename = vmalloc(strlen(pathname));
    memset(child_dir, 0, strlen(child_dir));
    memset(filename, 0, strlen(filename));
    memset(pathname, 0, strlen(pathname));
    strcpy(pathname, _pathname);
    // can not unlink root directory
	if ( strcmp(pathname, "/") == 0 ) {
		return -1;
	}

    // make sure the full path exists
	int file_inode_num = find_parent_directory_inode(pathname);
	if ( file_inode_num == -1 ) {
		return -1;
	}
	inode_struct* file_inode = &ramdisk->inodes[file_inode_num];
	
	// check if the directory is empty
	if (strcmp(file_inode->type, "dir\0") == 0) {
		if ( file_inode->size > 0 ) {
			return -1;
		}
	}

    // separate parent full path and child and find parent's inode
	separate_child_parent_path(pathname,child_pathname, filename);

    // find the i node for the directory
	int parent_inode_num = find_parent_directory_inode(child_pathname);
	if ( parent_inode_num == -1 ) {
		return -1;
	}
    // adjust global structures
	inode_struct* child_inode = &ramdisk->inodes[parent_inode_num];
	reset_inode(file_inode);
    clear_entry_in_child_dir(child_inode, filename);
	child_inode->size -= 16;

	memset(file_inode, 0 , sizeof(inode_struct));
	ramdisk->superblock.free_inodes++;
	vfree(child_dir);
	vfree(filename);
    vfree(pathname);

	return 0;

}


// set the file object's file position identified by file descriptor, fd, to offset, returning the new position, or the end of the file position if the offset is beyond the file's current size. 
// This call should return -1 to indicate an error, if applied to directory files, else 0 to indicate success.
int rd_lseek(int _fd, int offset, int pid) {

    // find the fd_table
    file_object* file_object = NULL;
    
    file_descriptor_table* file_objects = get_fd_table(pid);
    if (file_objects == NULL) {
        return -1;  
    }
    
    // find the file object
    int i;
    for ( i = 0; i < FD_TABLE_SIZE; i++ ) {
        if ( file_objects->file_objects[i].pos == _fd ) {
            file_object = &file_objects->file_objects[i];
            break;
        }
    }

    // file object not found
    inode_struct* inode = file_object->inode_ptr;
    if ( inode == NULL ) {
        return -1;
    }

    // fd not in use
    if (file_object->status == 0) {
        return -1;
    }

    // trying to lseek directory
    if (strcmp(inode->type, "dir") == 0) {
        return -1;
    }

    // lseek is larger than file size, just return to end
    int file_size = inode->size; 
    if ( offset >= file_size ) {
        file_object->cursor = file_size - 1;
        return 0;
    }

    file_object->cursor = offset;
    return 0;
}

//read one entry from a directory file identified by fd and store the result in memory at the specified value of address. When reading a given entry, you should return a 14 byte filename, 
//followed by a two byte index node number for the file. 1 is returned on success (to indicate a successfully read directory entry) and -1 on error. An error occurs if either of the arguments to rd_readdir() are invalid. 
//Each time a process calls rd_readdir() you should increment the file position in the corresponding file object to refer to the next entry. 
//If either the directory is empty or the last entry has been read by a previous call to rd_readdir() you should return 0, to indicate end-of-file.
int rd_readdir(int index_node_number, char *address, int *pos)
{
    // find the fd_table
    file_object* file_object = NULL;

    file_descriptor_table* file_objects = get_fd_table(pid);
    if (file_objects == NULL) {
        return -1;  
    }

    // find the file object
    int i;
    for ( i = 0; i < FD_TABLE_SIZE; i++ ) {
        if ( file_objects->file_objects[i].pos == _fd ) {
            file_object = &file_objects->file_objects[i];
            break;
        }
    }

    index_node = get_index_node(index_node_number);
    if (0 != strcmp("dir", index_node->type))
    {
        return -1;
    }
   
    // go through whole size of index node
    while (file_object->cursor < index_node->size)
    {
        entry = (dir_entry_t *)ramdisk_get_memory_address(&file_object->cursor);
        if (NULL == entry)
        {
        break;
        }
        file_object->cursor = file_object->cursor + sizeof(dir_entry_t);
        // if greater than block size add to next block
        if (file_object->cursor > 256)
        {
            file_object->cursor = file_object->cursor->locations++;
            file_object->cursor = file_object->cursor - sizeof(dir_entry_t);
            break;
        }

        // copy entry over to new address
        if (0 != strcmp(entry->filename, ""))
        {
        memcpy(address, entry, sizeof(dir_entry_t));
        *pos = file_object->cursor
        return 1;
        }
    }

    *pos = file_object->cursor
    return 0;
}