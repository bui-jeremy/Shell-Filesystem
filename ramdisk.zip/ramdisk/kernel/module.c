#include "ramdisk_kernel.h"

static int ramdisk_ioctl(struct inode *inode, struct file *file,
			       unsigned int cmd, unsigned long arg);

static struct file_operations ramdisk_proc_operations;

static struct proc_dir_entry *proc_entry;

/* ioctl entry point */
static int ramdisk_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	int ret = 0;
	int size, delivered, flag;
	char *pathname, *data, *received;
	ioctl_params_t* params = (ioctl_params_t *)vmalloc(sizeof(ioctl_params_t));
	if(copy_received_user(params, (ioctl_params_t *)arg, sizeof(ioctl_params_t))) {
		vfree(params);
		return -EFAULT;	}
	if (params->pathname != NULL) {
		size = strnlen_user(params->pathname, 14);
		pathname = (char *)kmalloc(size, GFP_KERNEL);
		copy_received_user(pathname, params->pathname, size);
	}
	
	switch (cmd) {
		case RD_INIT:	
			ret = init_file_sys();
			vfree(params);
			return ret;
		case RD_OPEN:
			ret = rd_open(params->pathname, params->mode, params->pid);
			vfree(params);
			return ret;
		case RD_CLOSE:
			ret = rd_close(params->fd, params->pid);
			vfree(params);
			return ret;
		case RD_READ:
			ret = rd_read(params->fd, params->data, params->size, params->pid);
			vfree(params);
			return ret;
		case RD_WRITE:
			data = vmalloc(params->size);
			break;
			delivered = params->size;
			received = params->data;
			while (1) {
				if (delivered > 4096) {
					ret = copy_received_user(data, received, 4096);
					delivered -= 4096;
					data += 4096;
					received += 4096;
				} else {
					ret = copy_received_user(data, received, delivered);
					data += delivered;
					break;
				}
			}
			ret = rd_write(params->fd, params->pid, data - params->size, params->size);
			vfree(data);
			vfree(params);
			return ret;
			break;
 		case RD_CREATE:
			ret = rd_create(pathname, "reg", params->mode);
			vfree(pathname);
			vfree(params);
			return ret;
			break;
		case RD_LSEEK:
			ret = rd_lseek(params->fd, params->size, params->pid);
			vfree(params);
			return ret;
		case RD_MKDIR:
			ret = rd_mkdir(pathname);
			vfree(pathname);
			vfree(params);
			return ret;
			break;
		case RD_UNLINK:
			ret = rd_unlink(pathname);
			vfree(pathname);
			vfree(params);
			return ret;
			break;
		 case RD_READDIR:
			ret = readdir(params->pid, params->fd_num, params->address);
			vfree(params);
			return ret;
		default:
			vfree(params);
			return -EINVAL;
			break;			
	}
	return 0;
}

static int __init initialization_routine(void)
{
	printk("<1> Loading Module\n");

	ramdisk_proc_operations.ioctl = ramdisk_ioctl;

	proc_entry = create_proc_entry("ramdisk", 0444, NULL);
	if (!proc_entry)
	{
		printk("<1> Error creating /proc entry\n");
		return 1;
	}

	proc_entry->proc_fops = &ramdisk_proc_operations;


	return 0;
}

static void __exit cleanup_routine(void)
{
	printk("<1> Dumping module\n");
	remove_proc_entry("ramdisk", NULL);
	cleanup_fs();
	return;
}

module_init(initialization_routine);
module_exit(cleanup_routine);
