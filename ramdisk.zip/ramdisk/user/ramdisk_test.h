#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define RD_INIT    _IOW(0, 0, ioctl_params_t*)
#define RD_CREATE  _IOW(0, 1, ioctl_params_t*)
#define RD_MKDIR   _IOW(0, 2, ioctl_params_t*)
#define RD_OPEN    _IOW(0, 3, ioctl_params_t*)
#define RD_CLOSE   _IOW(0, 4, ioctl_params_t*)
#define RD_READ    _IOW(0, 5, ioctl_params_t*)
#define RD_WRITE   _IOW(0, 6, ioctl_params_t*)
#define RD_LSEEK   _IOW(0, 7, ioctl_params_t*)
#define RD_UNLINK  _IOW(0, 8, ioctl_params_t*)
#define RD_READDIR _IOW(0, 9, ioctl_params_t*)

typedef struct ioctl_args {
	int pid;
	int fd;
	int size;  
	char* pathname;
	char* data;
} ioctl_params_t;

int rd_init();
int rd_creat(char* pathname);
int rd_mkdir(char* pathname);
int rd_open(char* pathname);
int rd_close(int _fd);
int rd_write(int _fd, char* data, int number_of_data);
int rd_read(int _fd, char* addr, int number_of_data);
int rd_unlink(char* pathname);
int rd_lseek(int _fd, int offset);
int rd_readdir(int _fd, char* addr);